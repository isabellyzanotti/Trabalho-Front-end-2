import estilos from './Zap.module.css';
function Zap() {

    return (
        <div>
            <img src="./images/dog.jpeg" className={estilos.dog}></img>
            <h1>Ah, que pena! 🥺 Não podemos passar o número do WhatsApp por aqui. Volte mais tarde! </h1>
        </div>
    )


}
export default Zap;